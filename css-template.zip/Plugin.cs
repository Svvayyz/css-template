﻿using CounterStrikeSharp.API.Core;
using Microsoft.Extensions.Logging;

namespace $safeprojectname$
{
    // Getting started:
    // https://docs.cssharp.dev/index.html

    public class Plugin : BasePlugin
    {
        public override string ModuleName => "Template Plguin";
        public override string ModuleVersion => "1.0.0";
        public override string ModuleAuthor => "Svvayyz";
        public override string ModuleDescription => "amethyst.rip";

        public override void Load(bool bHotReload)
        {
            Logger.LogInformation("Hello World! We are loading!");
        }

        public override void Unload(bool bHotReload)
        {
            Logger.LogInformation("Hello World! We are unloading!");
        }
    }
}
